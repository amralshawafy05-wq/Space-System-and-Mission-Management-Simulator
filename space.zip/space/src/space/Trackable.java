package space;

public interface Trackable {

    void track();
}