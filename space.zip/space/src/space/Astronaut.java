package space;

public class Astronaut extends Person {

    public Astronaut(String name, int age) {
        super(name, age);
    }

    @Override
    public void showRole() {
        System.out.println("Astronaut Name: " + getName());
        System.out.println("Age: " + getAge());
    }
}