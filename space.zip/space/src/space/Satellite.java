package space;

public class Satellite extends SpaceObject implements Trackable {

    private String orbitType;

    public Satellite(String name, String status, String orbitType) {
        super(name, status);
        this.orbitType = orbitType;
    }

    public String getOrbitType() {
        return orbitType;
    }

    public void setOrbitType(String orbitType) {
        this.orbitType = orbitType;
    }

    @Override
    public void displayInfo() {
        System.out.println("Satellite Name: " + getName());
        System.out.println("Status: " + getStatus());
        System.out.println("Orbit Type: " + orbitType);
    }

    @Override
    public void track() {
        System.out.println(getName() + " is being tracked.");
    }
}