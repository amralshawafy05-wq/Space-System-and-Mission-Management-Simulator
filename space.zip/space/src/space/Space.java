package space;

import java.util.Scanner;

public class Space {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        SpaceSystem system = new SpaceSystem();
        int choice;

        do {
            System.out.println("\n==============================");
            System.out.println("   SPACE MANAGEMENT SYSTEM");
            System.out.println("==============================");

            System.out.println("1. Show Satellites");
            System.out.println("2. Add Satellite");
            System.out.println("3. Show Space Stations");
            System.out.println("4. Add Space Station");
            System.out.println("5. Show People");
            System.out.println("6. Add Person");
            System.out.println("7. Show Missions");
            System.out.println("8. Add Mission");
            System.out.println("9. Track Satellite");
            System.out.println("10. Delete Satellite");
            System.out.println("11. Delete Space Station");
            System.out.println("12. Delete Person");
            System.out.println("13. Delete Mission");
            System.out.println("0. Exit");

            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            input.nextLine();

             switch (choice) {
                case 1:
                    system.showSatellites();
                    break;

                case 2:
                    System.out.print("Enter satellite name: ");
                    String satelliteName = input.nextLine();

                    System.out.print("Enter status: ");
                    String satelliteStatus = input.nextLine();

                    System.out.print("Enter orbit type: ");
                    String orbitType = input.nextLine();

                    Satellite satellite = new Satellite(
                            satelliteName, satelliteStatus, orbitType);
                    system.addSatellite(satellite);
                    System.out.println("Satellite added successfully.");
                    break;

                case 3:
                    system.showStations();
                    break;

                case 4:
                    System.out.print("Enter station name: ");
                    String stationName = input.nextLine();

                    System.out.print("Enter status: ");
                    String stationStatus = input.nextLine();

                    System.out.print("Enter crew members: ");
                    int crew = input.nextInt();
                    input.nextLine();

                    SpaceStation station = new SpaceStation(
                            stationName, stationStatus, crew);
                    system.addStation(station);
                    System.out.println("Station added successfully.");
                    break;

                case 5:
                    system.showPeople();
                    break;

                case 6:
                    System.out.println("1. Astronaut");
                    System.out.println("2. Engineer");
                    System.out.print("Choose type: ");
                    int personType = input.nextInt();
                    input.nextLine();

                    System.out.print("Enter name: ");
                    String personName = input.nextLine();

                    System.out.print("Enter age: ");
                    int age = input.nextInt();
                    input.nextLine();

                    if (personType == 1) {
                        system.addPerson(new Astronaut(personName, age));
                        System.out.println("Astronaut added successfully.");
                    } else if (personType == 2) {
                        system.addPerson(new Engineer(personName, age));
                        System.out.println("Engineer added successfully.");
                    } else {
                        System.out.println("Invalid type.");
                    }
                    break;

                 case 7:
                    system.showMissions();
                    break;

                 case 8:
                    if (system.getSatelliteCount() == 0) {
                        System.out.println("No satellites available.");
                        break;
                    }

                    System.out.print("Enter mission name: ");
                    String missionName = input.nextLine();

                    System.out.print("Enter destination: ");
                    String destination = input.nextLine();

                    system.showSatellites();
                    System.out.print("Choose satellite number (1-"
                            + system.getSatelliteCount() + "): ");
                    int satelliteNumber = input.nextInt();
                    input.nextLine();

                    if (satelliteNumber < 1
                            || satelliteNumber > system.getSatelliteCount()) {
                        System.out.println("Invalid satellite number.");
                        break;
                    }

                    Satellite selectedSatellite = system.getSatellite(
                            satelliteNumber - 1);
                    Mission mission = new Mission(
                            missionName, destination, selectedSatellite);
                    system.addMission(mission);
                    System.out.println("Mission added successfully.");
                    break;

                case 9:
                    trackSatellite(input, system);
                    break;

                case 10:
                    deleteSatellite(input, system);
                    break;

                case 11:
                    deleteStation(input, system);
                    break;

                case 12:
                    deletePerson(input, system);
                    break;

                case 13:
                    deleteMission(input, system);
                    break;

                case 0:
                    System.out.println("Program terminated.");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 0);

        input.close();
    }

    private static void trackSatellite(Scanner input, SpaceSystem system) {
        if (system.getSatelliteCount() == 0) {
            System.out.println("No satellites available.");
            return;
        }

        system.showSatellites();
        System.out.print("Choose satellite number (1-"
                + system.getSatelliteCount() + "): ");
        int trackNumber = input.nextInt();
        input.nextLine();

        if (trackNumber < 1
                || trackNumber > system.getSatelliteCount()) {
            System.out.println("Invalid satellite number.");
            return;
        }

        system.getSatellite(trackNumber - 1).track();
    }

    private static void deleteSatellite(Scanner input, SpaceSystem system) {
        if (system.getSatelliteCount() == 0) {
            System.out.println("No satellites available.");
            return;
        }

        system.showSatellites();
        System.out.print("Choose satellite number to delete (1-"
                + system.getSatelliteCount() + "): ");
        int number = input.nextInt();
        input.nextLine();

        if (system.deleteSatellite(number - 1)) {
            System.out.println(
                    "Satellite deleted successfully. Related missions were also removed.");
        } else {
            System.out.println("Invalid satellite number.");
        }
    }

    private static void deleteStation(Scanner input, SpaceSystem system) {
        if (system.getStationCount() == 0) {
            System.out.println("No space stations available.");
            return;
        }

        system.showStations();
        System.out.print("Choose station number to delete (1-"
                + system.getStationCount() + "): ");
        int number = input.nextInt();
        input.nextLine();

        if (system.deleteStation(number - 1)) {
            System.out.println("Space station deleted successfully.");
        } else {
            System.out.println("Invalid station number.");
        }
    }

    private static void deletePerson(Scanner input, SpaceSystem system) {
        if (system.getPersonCount() == 0) {
            System.out.println("No people available.");
            return;
        }

        system.showPeople();
        System.out.print("Choose person number to delete (1-"
                + system.getPersonCount() + "): ");
        int number = input.nextInt();
        input.nextLine();

        if (system.deletePerson(number - 1)) {
            System.out.println("Person deleted successfully.");
        } else {
            System.out.println("Invalid person number.");
        }
    }
    

    private static void deleteMission(Scanner input, SpaceSystem system) {
        if (system.getMissionCount() == 0) {
            System.out.println("No missions available.");
            return;
        }

        system.showMissions();
        System.out.print("Choose mission number to delete (1-"
                + system.getMissionCount() + "): ");
        int number = input.nextInt();
        input.nextLine();

        if (system.deleteMission(number - 1)) {
            System.out.println("Mission deleted successfully.");
        } else {
            System.out.println("Invalid mission number.");
        }
    }
}
