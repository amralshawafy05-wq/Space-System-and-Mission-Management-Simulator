package space;

public class Engineer extends Person {

    public Engineer(String name, int age) {
        super(name, age);
    }

    @Override
    public void showRole() {
        System.out.println("Engineer Name: " + getName());
        System.out.println("Age: " + getAge());
    }
}