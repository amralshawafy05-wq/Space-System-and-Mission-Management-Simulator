package space;

import java.util.ArrayList;
import java.util.List;

public class SpaceSystem {

    private List<Satellite> satellites;
    private List<SpaceStation> stations;
    private List<Mission> missions;
    private List<Person> people;

    public SpaceSystem() {
        satellites = new ArrayList<>();
        stations = new ArrayList<>();
        missions = new ArrayList<>();
        people = new ArrayList<>();

        addInitialData();
    }

    private void addInitialData() {
        Satellite s1 = new Satellite("Landsat 8", "ACTIVE", "LEO");
        Satellite s2 = new Satellite("GOES-16", "ACTIVE", "GEO");
        Satellite s3 = new Satellite("Al Yah 3", "ACTIVE", "GEO");

        satellites.add(s1);
        satellites.add(s2);
        satellites.add(s3);

        SpaceStation station = new SpaceStation(
                "International Space Station", "ACTIVE", 7);
        stations.add(station);

        Astronaut astronaut = new Astronaut("John", 35);
        Engineer engineer = new Engineer("Michael", 40);
        people.add(astronaut);
        people.add(engineer);

        Mission mission = new Mission(
                "Earth Observation", "Earth", s1);
        missions.add(mission);
    }

    public void addSatellite(Satellite satellite) {
        satellites.add(satellite);
    }

    public void addStation(SpaceStation station) {
        stations.add(station);
    }

    public void addPerson(Person person) {
        people.add(person);
    }

    public void addMission(Mission mission) {
        missions.add(mission);
    }

    public void showSatellites() {
        System.out.println("\n===== SATELLITES =====");
        if (satellites.isEmpty()) {
            System.out.println("No satellites available.");
            return;
        }

        for (int i = 0; i < satellites.size(); i++) {
            System.out.println("[" + (i + 1) + "]");
            satellites.get(i).displayInfo();
            System.out.println("--------------------");
        }
    }

    public void showStations() {
        System.out.println("\n===== SPACE STATIONS =====");
        if (stations.isEmpty()) {
            System.out.println("No space stations available.");
            return;
        }

        for (int i = 0; i < stations.size(); i++) {
            System.out.println("[" + (i + 1) + "]");
            stations.get(i).displayInfo();
            System.out.println("--------------------");
        }
    }

    public void showPeople() {
        System.out.println("\n===== PEOPLE =====");
        if (people.isEmpty()) {
            System.out.println("No people available.");
            return;
        }

        for (int i = 0; i < people.size(); i++) {
            System.out.println("[" + (i + 1) + "]");
            people.get(i).showRole();
            System.out.println("--------------------");
        }
    }

    public void showMissions() {
        System.out.println("\n===== MISSIONS =====");
        if (missions.isEmpty()) {
            System.out.println("No missions available.");
            return;
        }

        for (int i = 0; i < missions.size(); i++) {
            System.out.println("[" + (i + 1) + "]");
            missions.get(i).displayMission();
            System.out.println("--------------------");
        }
    }

    public Satellite getSatellite(int index) {
        return satellites.get(index);
    }

    public int getSatelliteCount() {
        return satellites.size();
    }

    public int getStationCount() {
        return stations.size();
    }

    public int getPersonCount() {
        return people.size();
    }

    public int getMissionCount() {
        return missions.size();
    }

    public boolean deleteSatellite(int index) {
        if (!isValidIndex(index, satellites.size())) {
            return false;
        }

        Satellite removedSatellite = satellites.remove(index);
        missions.removeIf(mission -> mission.getSatellite() == removedSatellite);
        return true;
    }

    public boolean deleteStation(int index) {
        if (!isValidIndex(index, stations.size())) {
            return false;
        }

        stations.remove(index);
        return true;
    }

    public boolean deletePerson(int index) {
        if (!isValidIndex(index, people.size())) {
            return false;
        }

        people.remove(index);
        return true;
    }

    public boolean deleteMission(int index) {
        if (!isValidIndex(index, missions.size())) {
            return false;
        }

        missions.remove(index);
        return true;
    }

    private boolean isValidIndex(int index, int size) {
        return index >= 0 && index < size;
    }
}
