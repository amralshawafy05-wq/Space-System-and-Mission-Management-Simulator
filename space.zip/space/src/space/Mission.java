package space;

public class Mission {

    private String missionName;
    private String destination;
    private Satellite satellite;

    public Mission(String missionName, String destination, Satellite satellite) {
        this.missionName = missionName;
        this.destination = destination;
        this.satellite = satellite;
    }

    public String getMissionName() {
        return missionName;
    }

    public void setMissionName(String missionName) {
        this.missionName = missionName;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Satellite getSatellite() {
        return satellite;
    }

    public void setSatellite(Satellite satellite) {
        this.satellite = satellite;
    }

    public void displayMission() {
        System.out.println("Mission Name: " + missionName);
        System.out.println("Destination: " + destination);
        System.out.println("Satellite: " + satellite.getName());
    }
}