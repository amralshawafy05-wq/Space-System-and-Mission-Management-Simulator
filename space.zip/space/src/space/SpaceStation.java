package space;

public class SpaceStation extends SpaceObject {

    private int crewMembers;

    public SpaceStation(String name, String status, int crewMembers) {
        super(name, status);
        this.crewMembers = crewMembers;
    }

    public int getCrewMembers() {
        return crewMembers;
    }

    public void setCrewMembers(int crewMembers) {
        this.crewMembers = crewMembers;
    }

    @Override
    public void displayInfo() {
        System.out.println("Station Name: " + getName());
        System.out.println("Status: " + getStatus());
        System.out.println("Crew Members: " + crewMembers);
    }
}